# HackMit

## Team Number: 19
## Team Number: Bhagwan Bharose
### Members:
1. Aniruddha Bagal
2. Arun Maurya
3. Dhavan Suresh
4. Yajat S

## To run Front-End:
1. `git clone https://github.com/aniruddhabagal/hackmit`
2. `cd frontend`
3. `npm i --force`

## To run Back-End:
1. `git checkout backend`
2. `cd backend`
3. `npm i`
4. `nodemon`

